
package oageng_payroll;

import java.util.*;
import java.io.*;

public class Oageng_UFPayroll {

    public static void main(String[] args) {

        // this is creating an object of the Scanner class named scanner
        Scanner scanner = new Scanner(System.in);

        boolean x = false;
        int numOfHours = 0;

        // this is a while loop that is used to validate the input of the employee's number of hours worked
        while (!x) {
            System.out.print("Enter your number of hours worked: ");
            numOfHours = scanner.nextInt();

            if (numOfHours > 0 ) {
                x = true;
            } else {
                System.out.println("\nInvalid option. Number of hours has to be a > 1.\n");
            }
        }

        boolean y = false;
        int shiftNumber = 0;

        // this is a while loop that is used to validate the input of the employee's shift number
        while (!y) {
            System.out.println("\nEnter your shift number (1, 2, or 3):");
            System.out.println("1 - First shift");
            System.out.println("2 - Second shift");
            System.out.println("3 - Third shift");
            shiftNumber = scanner.nextInt();

            if (shiftNumber > 0 && shiftNumber < 4) {
                y = true;
            } else {
                System.out.println("\nInvalid option. Number of hours has to be a > 1.");
            }
        }

        // this is an if statement that asks the employee about participating in the retirement plan
        if (shiftNumber == 2 || shiftNumber == 3) {
            System.out.print("\nWould you like to participate in the retirement plan? (yes/no): ");
            String choice = scanner.next();
            y = choice.equalsIgnoreCase("yes");
        }else{
            y = false;
        }

        double hourlyRate;

        // this is a switch case to initialize the hourlyRate depending  on the shift number of the employees
        switch (shiftNumber) {
            case 1:
                hourlyRate = 50;
                break;
            case 2:
                hourlyRate = 70;
                break;
            case 3:
                hourlyRate = 90;
                break;
            default:
                hourlyRate = 0;
                break;
        }

        // this is used to calculate the overtime rate of the employee
        double overtimeRate = hourlyRate * 1.5;

        double overtimePay;
        double regularPay;

        // this is an if statement used to calculate the regular pay and the overtime pay of the employee (if any)
        if (numOfHours > 40) {
            regularPay = hourlyRate * 40;
            overtimePay = (numOfHours - 40) * overtimeRate;
        } else {
            regularPay = hourlyRate * numOfHours;
            overtimePay = 0;
        }

        // this is used to calculate the total pay of the employee
        double totalPay = regularPay + overtimePay;

        double retirementDeduction;

        // this is an if statement used to calculate the retirement deduction of the employee (if any)
        if (y) {
            retirementDeduction = totalPay * 0.05;
        } else {
            retirementDeduction = 0;
        }

        // this is used to calculate the net pay of the employee
        double netPay = totalPay - retirementDeduction;

        // this is the payment breakdown 
        System.out.println("\n------------------------------------------");
        System.out.println("Hours Worked: " + numOfHours);
        System.out.println("Shift: " + shiftNumber);
        System.out.println("Hourly pay rate: R" + hourlyRate);
        System.out.println("Regular pay: R" + regularPay);
        System.out.println("Overtime pay: R" + overtimePay);
        System.out.println("Total of regular and overtime pay: R" + totalPay);
        System.out.println("Retirement deduction: R" + retirementDeduction);
        System.out.println("Net pay: R" + netPay);
        writeFile(numOfHours, shiftNumber, hourlyRate, regularPay, overtimePay, totalPay, retirementDeduction, netPay);
    }
    

    // this is a method that is used to write to the payroll file that makes use of these parameters 
    // (numOfHours, shiftNumber, hourlyRate, regularPay, overtimePay, totalPay, retirementDeduction, netPay) from the main class
    public static void writeFile(int numOfHours, int shiftNumber, double hourlyRate, double regularPay, double overtimePay, double totalPay, double retirementDeduction, double netPay) {
        try {
            // this is use to create a object of the RandomAccessFile class called payrollFile
            RandomAccessFile payrollFile = new RandomAccessFile("C:/Users/OAGENG.M/Documents/NetBeansProjects/Oageng_UFPayroll/payroll.txt", "rw");

            // this is used to move to the end of the file
            payrollFile.seek(payrollFile.length());

            // this is the payment breakdown that will saved into the payroll file
            payrollFile.writeBytes("\nHours Worked: " + numOfHours);
            payrollFile.writeBytes("\nShift: " + shiftNumber);
            payrollFile.writeBytes("\nHourly pay rate: R" + hourlyRate);
            payrollFile.writeBytes("\nRegular pay: R" + regularPay);
            payrollFile.writeBytes("\nOvertime pay: R" + overtimePay);
            payrollFile.writeBytes("\nTotal of regular and overtime pay: R" + totalPay);
            payrollFile.writeBytes("\nRetirement deduction: R" + retirementDeduction);
            payrollFile.writeBytes("\nNet pay: R" + netPay);
            payrollFile.writeBytes("\n------------------------------------------ >");

            // this is used to close the payroll file
            payrollFile.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // this is a methoed that is used to read from the payroll file that makes use of these parameters  
    // (numOfHours, shiftNumber, hourlyRate, regularPay, overtimePay, totalPay, retirementDeduction, netPay) from the main class
    public static void readFile(int numOfHours, int shiftNumber, double hourlyRate, double regularPay, double overtimePay, double totalPay, double retirementDeduction, double netPay) {
        try {
            // this is use to create a object of the RandomAccessFile class called payrollFile
            RandomAccessFile payrollFile = new RandomAccessFile("C:/Users/OAGENG.M/Documents/NetBeansProjects/Oageng_payroll/payroll.txt", "r");
            // this is used to start reading from the beginning of the file
            payrollFile.seek(0);

            // this is used to read and display each line from the payroll file
            String line;
            while ((line = payrollFile.readLine()) != null) {
                System.out.println(line);
            }
            // this is used to close the payroll file
            payrollFile.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }}