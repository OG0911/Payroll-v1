## Oageng_UFPayroll README

Oageng_UFPayroll is a simple payroll calculation program designed to handle various shifts and overtime calculations. It also considers the participation of employees in the retirement plan for second and third-shift workers.

## Features

- Input validation for hours worked and shift number.
- Calculation of regular and overtime pay.
- Deduction for retirement plan if opted in.
- Storage and retrieval of payroll data from a text file.

## Usage

1. Run the program.
2. Enter the number of hours worked.
3. Enter the shift number (1, 2, or 3).
4. If shift number is 2 or 3, choose whether to participate in the retirement plan.
5. The program will display a detailed breakdown of the payroll information.
6. The data will be saved to a file, and previous records can be read.

- Input Validation: The program validates user input and provides appropriate messages for invalid operations.

## Dependencies

- Java Development Kit (JDK)

## How to Run

- Clone the repository or download the source code.
- Open the Project: Open the project in your Java IDE (e.g., Apache NetBeans, Eclipse).
- Compile and Run: Compile and run the Oageng_UFPayroll.java file.
- Menu Navigation: Upon running the program, a menu will be displayed with the following options:

## Created by

- This project is created by Oageng Mbaitsela.

