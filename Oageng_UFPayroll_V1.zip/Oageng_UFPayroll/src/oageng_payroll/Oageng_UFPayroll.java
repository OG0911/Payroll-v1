
package oageng_payroll;

import java.util.*;

public class Oageng_UFPayroll {

    public static void main(String[] args) {

        // this is creating an object of the Scanner class named scanner
        Scanner scanner = new Scanner(System.in);

        boolean x = false;
        int numOfHours = 0;

        // this is a while loop that is used to validate the input of the employee's number of hours worked
        while (!x) {
            System.out.print("Enter your number of hours worked: ");
            numOfHours = scanner.nextInt();

            if (numOfHours > 0 ) {
                x = true;
            } else {
                System.out.println("\nInvalid option. Number of hours has to be a > 1.\n");
            }
        }

        boolean y = false;
        int shiftNumber = 0;

        // this is a while loop that is used to validate the input of the employee's shift number
        while (!y) {
            System.out.println("\nEnter your shift number (1, 2, or 3):");
            System.out.println("1 - First shift");
            System.out.println("2 - Second shift");
            System.out.println("3 - Third shift");
            shiftNumber = scanner.nextInt();

            if (shiftNumber > 0 && shiftNumber < 4) {
                y = true;
            } else {
                System.out.println("\nInvalid option. Number of hours has to be a > 1.");
            }
        }

        // this is an if statement that asks the employee about participating in the retirement plan
        if (shiftNumber == 2 || shiftNumber == 3) {
            System.out.print("\nWould you like to participate in the retirement plan? (yes/no): ");
            String choice = scanner.next();
            y = choice.equalsIgnoreCase("yes");
        }else{
            y = false;
        }

        double hourlyRate;

        // this is a switch case to initialize the hourlyRate depending  on the shift number of the employees
        switch (shiftNumber) {
            case 1:
                hourlyRate = 50;
                break;
            case 2:
                hourlyRate = 70;
                break;
            case 3:
                hourlyRate = 90;
                break;
            default:
                hourlyRate = 0;
                break;
        }

        // this is used to calculate the overtime rate of the employee
        double overtimeRate = hourlyRate * 1.5;

        double overtimePay;
        double regularPay;

        // this is an if statement used to calculate the regular pay and the overtime pay of the employee (if any)
        if (numOfHours > 40) {
            regularPay = hourlyRate * 40;
            overtimePay = (numOfHours - 40) * overtimeRate;
        } else {
            regularPay = hourlyRate * numOfHours;
            overtimePay = 0;
        }

        // this is used to calculate the total pay of the employee
        double totalPay = regularPay + overtimePay;

        double retirementDeduction;

        // this is an if statement used to calculate the retirement deduction of the employee (if any)
        if (y) {
            retirementDeduction = totalPay * 0.05;
        } else {
            retirementDeduction = 0;
        }

        // this is used to calculate the net pay of the employee
        double netPay = totalPay - retirementDeduction;

        // this is the payment breakdown 
        System.out.println("\n------------------------------------------");
        System.out.println("Hours Worked: " + numOfHours);
        System.out.println("Shift: " + shiftNumber);
        System.out.println("Hourly pay rate: R" + hourlyRate);
        System.out.println("Regular pay: R" + regularPay);
        System.out.println("Overtime pay: R" + overtimePay);
        System.out.println("Total of regular and overtime pay: R" + totalPay);
        System.out.println("Retirement deduction: R" + retirementDeduction);
        System.out.println("Net pay: R" + netPay);
    }
    }